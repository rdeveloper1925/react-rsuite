import React from "react";
import { Grid, Row, Col, Schema } from "rsuite";
import { CompleteForm } from "../Components/Inputs";
import { CompleteModal, WidgetCards } from "../Components/Utilities";

function Customers() {
  const formValidation = Schema.Model({
    customerName: Schema.Types.StringType().isRequired(
      "Customer Name is required"
    ),
    address: Schema.Types.StringType().isRequired("Address is required"),
    email: Schema.Types.StringType().isEmail("Provide a valid email"),
    contactPerson: Schema.Types.StringType().isRequired(
      "Contact Person is required"
    ),
    phone: Schema.Types.NumberType()
      .min(11111111, "Enter a valid length of phone number")
      .max(99999999999, "Enter a valid length of phone number")
      .isRequired("Phone is required"),
  });
  const fields = [
    { name: "customerName", label: "Customer Name", type: "text" },
    { name: "address", label: "Address", type: "text" },
    { name: "email", label: "Email", type: "text" },
    { name: "contactPerson", label: "ContactPerson", type: "text" },
    { name: "phone", label: "phone", type: "number" },
  ];

  const submitHandler = (formValue, event) => {
    //formValue will be false if form has validation errors and true otherwise
    if (formValue) {
      let formData = {};
      for (let i = 0; i <= fields.length; i++) {
        formData[event.target[i].name] = event.target[i].value;
      }
      //processed the form data as formData
      console.log(formData);
    }
  };
  return (
    <div>
      <h3>Customers</h3>
      <Grid fluid>
        <Row className="show-grid">
          <Col xs={24} sm={12} md={6} lg="3">
            <WidgetCards style={{ backgroundColor: "green" }}>
              128 Customers
            </WidgetCards>
          </Col>
        </Row>
        <CompleteModal title="Add Customer">
          <CompleteForm
            onSubmit={submitHandler}
            validation={formValidation}
            fields={fields}
          />
        </CompleteModal>
      </Grid>
    </div>
  );
}

export default Customers;
