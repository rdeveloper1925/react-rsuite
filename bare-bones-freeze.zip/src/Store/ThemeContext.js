import React from "react";

const ThemeContext = React.createContext("dark");
export default ThemeContext;
