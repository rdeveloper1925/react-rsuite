import React from "react";
import { Col, Container, Grid, Row } from "rsuite";

function Dashboard() {
  return (
    <Grid style={{ margin: "15px" }}>
      <Row>
        <Col xs={4}>ONe</Col>
        <Col xs={4}>ONe</Col>
        <Col xs={4}>ONe</Col>
      </Row>
    </Grid>
  );
}

export default Dashboard;
